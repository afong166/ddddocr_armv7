# ddddocr ARMv7 自动构建

## 使用 GitHub Actions 构建 ARMv7 镜像

### 步骤 1：创建 GitHub 仓库

1. 在 GitHub 创建新仓库（如 `ddddocr-armv7`）
2. 上传本文件夹内容到仓库

### 步骤 2：触发构建

**方式 A：手动触发**
- 进入仓库 Actions 页面
- 选择 "Build ddddocr ARMv7 Image"
- 点击 "Run workflow"

**方式 B：自动触发**
- 推送代码到 main 分支自动触发

### 步骤 3：下载镜像

构建完成后，在 Actions 页面或 Releases 下载：
- `ddddocr-armv7.tar.gz`

### 步骤 4：在玩客云导入

```bash
# 下载镜像到玩客云
# 然后导入
docker load -i ddddocr-armv7.tar.gz

# 运行
docker run -d -p 7777:7777 --restart=always --name ddddocr ddddocr:armv7
```

### 步骤 5：测试 API

```bash
curl http://localhost:7777/
```

## 文件说明

- `.github/workflows/build-ddddocr-armv7.yml` - GitHub Actions 配置
- 使用 QEMU 模拟 ARMv7 架构构建
- 构建时间约 30-60 分钟
